export class Drawing {
    constructor(drawingId, color, lineWidth, pathData, timestamp, user) {
      this.drawingId = drawingId;
      this.color = color;
      this.lineWidth = lineWidth;
      this.pathData = pathData;
      this.timestamp = timestamp;
      this.user = user;
      this.brushStyle = "round";
      this.order = timestamp;
    }
  }
  